/** Returns the hour (0-23) and ISO weekday (1=Mon..7=Sun) for `date` in `timeZone`. */
export function localParts(date: Date, timeZone: string): { hour: number; weekday: number } {
  let tz = timeZone;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
  } catch {
    tz = "UTC";
  }
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    hour: "numeric",
    hourCycle: "h23",
    weekday: "short",
  }).formatToParts(date);
  const hour = Number(parts.find((p) => p.type === "hour")?.value ?? 0);
  const wd = parts.find((p) => p.type === "weekday")?.value ?? "Mon";
  const map: Record<string, number> = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };
  return { hour, weekday: map[wd] ?? 1 };
}

export function isWithinSendWindow(
  campaign: { timezone: string; sendStartHour: number; sendEndHour: number; sendDays: string },
  now = new Date()
): boolean {
  const { hour, weekday } = localParts(now, campaign.timezone);
  const days = campaign.sendDays.split(",").map((d) => Number(d.trim()));
  return days.includes(weekday) && hour >= campaign.sendStartHour && hour < campaign.sendEndHour;
}

export function todayKey(now = new Date()): string {
  return now.toISOString().slice(0, 10);
}
