export type Vars = Record<string, string | null | undefined>;

/**
 * Renders a template:
 *   {{firstName}}          -> value (empty string if missing)
 *   {{firstName|there}}    -> value, or "there" when missing
 *   {Hi|Hello|Hey}         -> one random option (spintax)
 * Variables are resolved first, then spintax.
 */
export function render(template: string, vars: Vars): string {
  const withVars = template.replace(
    /\{\{\s*([\w.]+)\s*(?:\|([^}]*))?\}\}/g,
    (_m, name: string, fallback?: string) => {
      const v = vars[name];
      if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
      return fallback?.trim() ?? "";
    }
  );
  return withVars.replace(/\{([^{}]*\|[^{}]*)\}/g, (_m, options: string) => {
    const parts = options.split("|");
    return parts[Math.floor(Math.random() * parts.length)];
  });
}

export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function textToHtml(text: string): string {
  return escapeHtml(text).replace(/\r?\n/g, "<br>");
}

export function leadVars(lead: {
  email: string;
  firstName: string | null;
  lastName: string | null;
  company: string | null;
  vars: unknown;
}): Vars {
  const extra =
    lead.vars && typeof lead.vars === "object" ? (lead.vars as Record<string, unknown>) : {};
  const out: Vars = {};
  for (const [k, v] of Object.entries(extra)) out[k] = v == null ? "" : String(v);
  return {
    ...out,
    email: lead.email,
    firstName: lead.firstName,
    lastName: lead.lastName,
    company: lead.company,
  };
}
