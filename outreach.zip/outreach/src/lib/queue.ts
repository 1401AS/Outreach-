import IORedis from "ioredis";
import { Queue } from "bullmq";

export const SEND_QUEUE = "send";

const g = globalThis as unknown as { redis?: IORedis; sendQueue?: Queue };

export function redis() {
  if (!g.redis) {
    g.redis = new IORedis(process.env.REDIS_URL ?? "redis://localhost:6379", {
      maxRetriesPerRequest: null,
    });
  }
  return g.redis;
}

export function sendQueue() {
  if (!g.sendQueue) {
    g.sendQueue = new Queue(SEND_QUEUE, {
      connection: redis(),
      defaultJobOptions: { removeOnComplete: 1000, removeOnFail: 1000, attempts: 1 },
    });
  }
  return g.sendQueue;
}
