import { NextResponse } from "next/server";
import type { User } from "@prisma/client";
import { ZodError } from "zod";
import { getUser } from "./auth";

type Ctx = { params: Record<string, string> };

/** Wraps a route handler: requires a logged-in user, maps errors to JSON responses. */
export function withUser(
  fn: (req: Request, ctx: Ctx, user: User) => Promise<Response | object>
) {
  return async (req: Request, ctx: Ctx) => {
    try {
      const user = await getUser();
      if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
      const res = await fn(req, ctx, user);
      return res instanceof Response ? res : NextResponse.json(res);
    } catch (e) {
      return errorResponse(e);
    }
  };
}

export function errorResponse(e: unknown) {
  if (e instanceof ZodError) {
    const msg = e.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    return NextResponse.json({ error: msg }, { status: 400 });
  }
  if (e instanceof HttpError) {
    return NextResponse.json({ error: e.message }, { status: e.status });
  }
  console.error(e);
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}
