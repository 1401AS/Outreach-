import nodemailer from "nodemailer";
import { ImapFlow } from "imapflow";
import type { Mailbox } from "@prisma/client";
import { decrypt } from "./crypto";

export type ConnectionSettings = {
  smtpHost: string;
  smtpPort: number;
  imapHost: string;
  imapPort: number;
  username: string;
  password: string;
};

export function smtpTransport(c: ConnectionSettings) {
  return nodemailer.createTransport({
    host: c.smtpHost,
    port: c.smtpPort,
    secure: c.smtpPort === 465,
    auth: { user: c.username, pass: c.password },
    connectionTimeout: 15_000,
    greetingTimeout: 15_000,
    socketTimeout: 30_000,
  });
}

export function imapClient(c: ConnectionSettings) {
  return new ImapFlow({
    host: c.imapHost,
    port: c.imapPort,
    secure: c.imapPort === 993,
    auth: { user: c.username, pass: c.password },
    logger: false,
  });
}

export function settingsFromMailbox(mb: Mailbox): ConnectionSettings {
  return {
    smtpHost: mb.smtpHost,
    smtpPort: mb.smtpPort,
    imapHost: mb.imapHost,
    imapPort: mb.imapPort,
    username: mb.username,
    password: decrypt(mb.passwordEnc),
  };
}

/** Throws with a readable message if SMTP or IMAP login fails. */
export async function verifyConnection(c: ConnectionSettings) {
  try {
    await smtpTransport(c).verify();
  } catch (e) {
    throw new Error(`SMTP failed: ${(e as Error).message}`);
  }
  const client = imapClient(c);
  try {
    await client.connect();
    await client.logout();
  } catch (e) {
    throw new Error(`IMAP failed: ${(e as Error).message}`);
  }
}
