import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Outreach",
  description: "Cold email outreach platform",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
