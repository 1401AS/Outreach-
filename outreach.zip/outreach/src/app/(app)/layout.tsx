import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import LogoutButton from "@/components/LogoutButton";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();
  if (!user) redirect("/login");

  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">Outreach</div>
        <Link className="nav" href="/dashboard">Dashboard</Link>
        <Link className="nav" href="/campaigns">Campaigns</Link>
        <Link className="nav" href="/leads">Leads</Link>
        <Link className="nav" href="/mailboxes">Email accounts</Link>
        <Link className="nav" href="/inbox">Inbox</Link>
        <div className="grow" />
        <div className="muted" style={{ padding: "0 10px", fontSize: 12, wordBreak: "break-all" }}>{user.email}</div>
        <div style={{ padding: "6px 10px" }}><LogoutButton /></div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
