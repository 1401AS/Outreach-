"use client";

import { useState } from "react";

const LABELS = ["Interested", "Meeting booked", "Not interested", "Out of office", "Wrong person"];

export default function LabelSelect({ campaignLeadId, initial }: { campaignLeadId: string; initial: string | null }) {
  const [value, setValue] = useState(initial ?? "");
  const [error, setError] = useState(false);

  async function change(next: string) {
    const prev = value;
    setValue(next);
    setError(false);
    const res = await fetch(`/api/campaign-leads/${campaignLeadId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: next || null }),
    });
    if (!res.ok) {
      setValue(prev);
      setError(true);
    }
  }

  return (
    <div>
      <select value={value} onChange={(e) => change(e.target.value)} style={{ width: 170 }}>
        <option value="">No label</option>
        {LABELS.map((l) => <option key={l} value={l}>{l}</option>)}
      </select>
      {error && <div className="err" style={{ margin: 0, fontSize: 12 }}>Could not save</div>}
    </div>
  );
}
