import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import LabelSelect from "./LabelSelect";

export default async function InboxPage() {
  const user = await getUser();
  if (!user) redirect("/login");

  const replies = await prisma.message.findMany({
    where: { userId: user.id, direction: "IN", campaignLeadId: { not: null } },
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      mailbox: { select: { email: true } },
      campaignLead: {
        select: { id: true, label: true, campaign: { select: { name: true } }, lead: { select: { firstName: true, lastName: true, company: true } } },
      },
    },
  });

  return (
    <>
      <h1>Inbox</h1>
      <p className="sub">Replies to your campaigns across all connected mailboxes. Replying stops that lead&apos;s sequence automatically.</p>
      <div className="card">
        {replies.length === 0 ? (
          <p className="muted" style={{ margin: 0 }}>No replies yet. New replies appear here within about a minute.</p>
        ) : (
          replies.map((m) => {
            const lead = m.campaignLead!.lead;
            const who = [lead.firstName, lead.lastName].filter(Boolean).join(" ");
            return (
              <div className="msg" key={m.id}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                  <div>
                    <b>{who || m.fromEmail}</b> <span className="muted">&lt;{m.fromEmail}&gt;</span>
                    {lead.company && <span className="muted"> · {lead.company}</span>}
                    <div className="muted">
                      {m.subject} · {m.campaignLead!.campaign.name} · to {m.mailbox.email} · {m.createdAt.toLocaleString()}
                    </div>
                  </div>
                  <LabelSelect campaignLeadId={m.campaignLead!.id} initial={m.campaignLead!.label} />
                </div>
                <pre>{m.body.slice(0, 1500)}</pre>
              </div>
            );
          })
        )}
      </div>
    </>
  );
}
