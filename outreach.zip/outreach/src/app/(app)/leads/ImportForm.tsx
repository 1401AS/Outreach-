"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ImportForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [csv, setCsv] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState("");

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsv(await file.text());
    if (!name) setName(file.name.replace(/\.csv$/i, ""));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setResult("");
    const res = await fetch("/api/leads/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listName: name, csv }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setError(data.error ?? "Import failed");
    setResult(`Imported ${data.imported} leads (${data.invalid} invalid, ${data.duplicates} duplicates skipped).`);
    setName("");
    setCsv("");
    router.refresh();
  }

  return (
    <form className="card" onSubmit={submit}>
      <h2>Import leads from CSV</h2>
      <div className="row">
        <div>
          <label>List name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label>CSV file</label>
          <input type="file" accept=".csv,text/csv" onChange={onFile} />
          <div className="hint">
            Needs an <b>email</b> column. Optional: <b>firstName</b>, <b>lastName</b>, <b>company</b>. Any other column becomes a variable you can use as {"{{columnName}}"}.
          </div>
        </div>
        <div>
          <label>…or paste CSV</label>
          <textarea
            value={csv}
            onChange={(e) => setCsv(e.target.value)}
            placeholder={"email,firstName,company\njane@acme.com,Jane,Acme"}
            required
          />
        </div>
      </div>
      {error && <div className="err">{error}</div>}
      {result && <div className="ok">{result}</div>}
      <button disabled={busy}>{busy ? "Importing…" : "Import"}</button>
    </form>
  );
}
