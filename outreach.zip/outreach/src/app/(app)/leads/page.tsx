import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import ImportForm from "./ImportForm";

export default async function LeadsPage() {
  const user = await getUser();
  if (!user) redirect("/login");

  const lists = await prisma.leadList.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { leads: true } } },
  });

  return (
    <>
      <h1>Leads</h1>
      <p className="sub">Import a CSV to create a lead list.</p>

      <div className="card">
        {lists.length === 0 ? (
          <p className="muted" style={{ margin: 0 }}>No lead lists yet.</p>
        ) : (
          <table>
            <thead><tr><th>List</th><th>Leads</th><th>Created</th></tr></thead>
            <tbody>
              {lists.map((l) => (
                <tr key={l.id}>
                  <td>{l.name}</td>
                  <td>{l._count.leads}</td>
                  <td className="muted">{l.createdAt.toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <ImportForm />
    </>
  );
}
