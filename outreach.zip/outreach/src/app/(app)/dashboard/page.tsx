import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";

export default async function Dashboard() {
  const user = await getUser();
  if (!user) redirect("/login");

  const [sent, replies, opened, bounced, activeCampaigns, mailboxes] = await Promise.all([
    prisma.message.count({ where: { userId: user.id, direction: "OUT" } }),
    prisma.message.count({ where: { userId: user.id, direction: "IN" } }),
    prisma.message.count({ where: { userId: user.id, direction: "OUT", openCount: { gt: 0 } } }),
    prisma.campaignLead.count({ where: { status: "BOUNCED", campaign: { userId: user.id } } }),
    prisma.campaign.count({ where: { userId: user.id, status: "ACTIVE" } }),
    prisma.mailbox.count({ where: { userId: user.id } }),
  ]);

  const pct = (n: number) => (sent === 0 ? "—" : `${((n / sent) * 100).toFixed(1)}%`);
  const stats = [
    { l: "Emails sent", n: sent },
    { l: "Replies", n: replies, sub: pct(replies) },
    { l: "Opened", n: opened, sub: pct(opened) },
    { l: "Bounced", n: bounced, sub: pct(bounced) },
    { l: "Active campaigns", n: activeCampaigns },
    { l: "Email accounts", n: mailboxes },
  ];

  return (
    <>
      <h1>Dashboard</h1>
      <p className="sub">Overview of everything you have sent.</p>
      <div className="grid stats">
        {stats.map((s) => (
          <div className="card stat" key={s.l} style={{ marginBottom: 0 }}>
            <div className="n">{s.n}</div>
            <div className="l">{s.l}</div>
            {s.sub && <div className="muted">{s.sub} of sent</div>}
          </div>
        ))}
      </div>

      {mailboxes === 0 && (
        <div className="card" style={{ marginTop: 18 }}>
          <h2>Get started</h2>
          <ol style={{ margin: 0, paddingLeft: 18 }}>
            <li><Link href="/mailboxes">Connect an email account</Link></li>
            <li><Link href="/leads">Import a lead list</Link></li>
            <li><Link href="/campaigns/new">Create and launch a campaign</Link></li>
          </ol>
        </div>
      )}
      <p className="hint" style={{ marginTop: 14 }}>
        Open tracking uses a tiny image, so email apps that preload images can inflate open counts. Replies are the number to trust.
      </p>
    </>
  );
}
