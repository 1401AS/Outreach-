"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const PRESETS: Record<string, { smtpHost: string; smtpPort: number; imapHost: string; imapPort: number }> = {
  gmail: { smtpHost: "smtp.gmail.com", smtpPort: 465, imapHost: "imap.gmail.com", imapPort: 993 },
  outlook: { smtpHost: "smtp.office365.com", smtpPort: 587, imapHost: "outlook.office365.com", imapPort: 993 },
  custom: { smtpHost: "", smtpPort: 465, imapHost: "", imapPort: 993 },
};

export default function MailboxForm() {
  const router = useRouter();
  const [preset, setPreset] = useState("gmail");
  const [f, setF] = useState({
    email: "",
    fromName: "",
    password: "",
    dailyLimit: 30,
    ...PRESETS.gmail,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const set = (k: string, v: string | number) => setF((p) => ({ ...p, [k]: v }));

  function pick(p: string) {
    setPreset(p);
    setF((prev) => ({ ...prev, ...PRESETS[p] }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/mailboxes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...f, username: f.email }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setError(data.error ?? "Could not connect");
    setF((p) => ({ ...p, email: "", fromName: "", password: "" }));
    router.refresh();
  }

  return (
    <form className="card" onSubmit={submit}>
      <h2>Connect an email account</h2>
      <div className="row c2">
        <div>
          <label>Provider</label>
          <select value={preset} onChange={(e) => pick(e.target.value)}>
            <option value="gmail">Gmail / Google Workspace</option>
            <option value="outlook">Outlook / Microsoft 365</option>
            <option value="custom">Other (custom SMTP/IMAP)</option>
          </select>
        </div>
        <div>
          <label>Daily send limit</label>
          <input type="number" min={1} max={500} value={f.dailyLimit} onChange={(e) => set("dailyLimit", Number(e.target.value))} />
          <div className="hint">Start low (20–30/day) on new mailboxes.</div>
        </div>
      </div>
      <div className="row c2">
        <div>
          <label>Email address</label>
          <input type="email" value={f.email} onChange={(e) => set("email", e.target.value)} required />
        </div>
        <div>
          <label>Sender name</label>
          <input value={f.fromName} onChange={(e) => set("fromName", e.target.value)} placeholder="Jane Smith" required />
        </div>
      </div>
      <div className="row">
        <div>
          <label>App password</label>
          <input type="password" value={f.password} onChange={(e) => set("password", e.target.value)} required />
          {preset === "gmail" && (
            <div className="hint">
              Use a Google App Password (Google Account → Security → 2-Step Verification → App passwords), not your normal password.
            </div>
          )}
          {preset === "outlook" && (
            <div className="hint">
              Microsoft is phasing out password (basic) auth for SMTP/IMAP, so this may be rejected. OAuth sign-in is the reliable route for Outlook.
            </div>
          )}
        </div>
      </div>
      {preset === "custom" && (
        <div className="row c4">
          <div><label>SMTP host</label><input value={f.smtpHost} onChange={(e) => set("smtpHost", e.target.value)} required /></div>
          <div><label>SMTP port</label><input type="number" value={f.smtpPort} onChange={(e) => set("smtpPort", Number(e.target.value))} required /></div>
          <div><label>IMAP host</label><input value={f.imapHost} onChange={(e) => set("imapHost", e.target.value)} required /></div>
          <div><label>IMAP port</label><input type="number" value={f.imapPort} onChange={(e) => set("imapPort", Number(e.target.value))} required /></div>
        </div>
      )}
      {error && <div className="err">{error}</div>}
      <button disabled={busy}>{busy ? "Testing connection…" : "Connect"}</button>
    </form>
  );
}
