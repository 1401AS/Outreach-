import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import ActionButton from "@/components/ActionButton";
import MailboxForm from "./MailboxForm";

export default async function MailboxesPage() {
  const user = await getUser();
  if (!user) redirect("/login");

  const mailboxes = await prisma.mailbox.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
  });

  return (
    <>
      <h1>Email accounts</h1>
      <p className="sub">Connect the mailboxes you send from. Credentials are encrypted at rest.</p>

      <div className="card">
        {mailboxes.length === 0 ? (
          <p className="muted" style={{ margin: 0 }}>No email accounts yet. Add one below.</p>
        ) : (
          <table>
            <thead>
              <tr><th>Email</th><th>Status</th><th>Sent today</th><th></th></tr>
            </thead>
            <tbody>
              {mailboxes.map((m) => (
                <tr key={m.id}>
                  <td>
                    {m.email}
                    <div className="muted">{m.fromName}</div>
                    {m.lastError && <div className="err" style={{ margin: 0, fontSize: 12 }}>{m.lastError}</div>}
                  </td>
                  <td><span className={`badge ${m.status}`}>{m.status}</span></td>
                  <td>{m.sentToday} / {m.dailyLimit}</td>
                  <td style={{ textAlign: "right" }}>
                    <ActionButton
                      url={`/api/mailboxes/${m.id}`}
                      method="DELETE"
                      label="Remove"
                      className="danger sm"
                      confirm={`Remove ${m.email}? Campaigns using it will lose this mailbox.`}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <MailboxForm />
    </>
  );
}
