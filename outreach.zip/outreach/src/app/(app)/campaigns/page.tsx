import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import ActionButton from "@/components/ActionButton";

export default async function CampaignsPage() {
  const user = await getUser();
  if (!user) redirect("/login");

  const campaigns = await prisma.campaign.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    include: { list: { select: { name: true } }, _count: { select: { campaignLeads: true } } },
  });

  const rows = await Promise.all(
    campaigns.map(async (c) => {
      const [sent, replies, opened, bounced] = await Promise.all([
        prisma.message.count({ where: { direction: "OUT", campaignLead: { campaignId: c.id } } }),
        prisma.message.count({ where: { direction: "IN", campaignLead: { campaignId: c.id } } }),
        prisma.message.count({
          where: { direction: "OUT", openCount: { gt: 0 }, campaignLead: { campaignId: c.id } },
        }),
        prisma.campaignLead.count({ where: { campaignId: c.id, status: "BOUNCED" } }),
      ]);
      return { c, sent, replies, opened, bounced };
    })
  );

  return (
    <>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1>Campaigns</h1>
          <p className="sub" style={{ marginBottom: 20 }}>Sequences that send automatically.</p>
        </div>
        <Link className="btn" href="/campaigns/new">New campaign</Link>
      </div>

      <div className="card">
        {rows.length === 0 ? (
          <p className="muted" style={{ margin: 0 }}>No campaigns yet.</p>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>Status</th><th>Leads</th><th>Sent</th><th>Opened</th><th>Replies</th><th>Bounced</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map(({ c, sent, replies, opened, bounced }) => (
                <tr key={c.id}>
                  <td>{c.name}<div className="muted">{c.list.name}</div></td>
                  <td><span className={`badge ${c.status}`}>{c.status}</span></td>
                  <td>{c._count.campaignLeads}</td>
                  <td>{sent}</td>
                  <td>{opened}</td>
                  <td>{replies}</td>
                  <td>{bounced}</td>
                  <td style={{ textAlign: "right" }}>
                    {c.status === "DRAFT" && (
                      <ActionButton
                        url={`/api/campaigns/${c.id}/status`}
                        body={{ action: "launch" }}
                        label="Launch"
                        className="sm"
                        confirm="Launch this campaign? Emails start sending within your send window."
                      />
                    )}
                    {c.status === "ACTIVE" && (
                      <ActionButton url={`/api/campaigns/${c.id}/status`} body={{ action: "pause" }} label="Pause" className="ghost sm" />
                    )}
                    {c.status === "PAUSED" && (
                      <ActionButton url={`/api/campaigns/${c.id}/status`} body={{ action: "resume" }} label="Resume" className="sm" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
