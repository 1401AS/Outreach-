"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type Step = { delayDays: number; subject: string; body: string };

const DAYS = [
  { n: 1, l: "Mon" }, { n: 2, l: "Tue" }, { n: 3, l: "Wed" }, { n: 4, l: "Thu" },
  { n: 5, l: "Fri" }, { n: 6, l: "Sat" }, { n: 7, l: "Sun" },
];

export default function CampaignBuilder({
  lists,
  mailboxes,
}: {
  lists: { id: string; name: string }[];
  mailboxes: { id: string; email: string }[];
}) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [listId, setListId] = useState(lists[0]?.id ?? "");
  const [mailboxIds, setMailboxIds] = useState<string[]>(mailboxes.map((m) => m.id));
  const [timezone, setTimezone] = useState("UTC");
  const [start, setStart] = useState(9);
  const [end, setEnd] = useState(17);
  const [days, setDays] = useState<number[]>([1, 2, 3, 4, 5]);
  const [trackOpens, setTrackOpens] = useState(true);
  const [steps, setSteps] = useState<Step[]>([
    { delayDays: 0, subject: "Quick question, {{firstName|there}}", body: "Hi {{firstName|there}},\n\n\n\nBest,\nYour name" },
  ]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    try {
      setTimezone(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
    } catch {
      /* keep UTC */
    }
  }, []);

  const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  const updateStep = (i: number, patch: Partial<Step>) =>
    setSteps((s) => s.map((st, idx) => (idx === i ? { ...st, ...patch } : st)));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/campaigns", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        listId,
        mailboxIds,
        timezone,
        sendStartHour: start,
        sendEndHour: end,
        sendDays: days,
        trackOpens,
        steps,
      }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) return setError(data.error ?? "Could not create campaign");
    router.push("/campaigns");
    router.refresh();
  }

  return (
    <form onSubmit={submit}>
      <div className="card">
        <h2>Setup</h2>
        <div className="row c2">
          <div>
            <label>Campaign name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div>
            <label>Lead list</label>
            <select value={listId} onChange={(e) => setListId(e.target.value)}>
              {lists.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
          </div>
        </div>
        <label>Send from (emails rotate across the selected accounts)</label>
        <div className="checks">
          {mailboxes.map((m) => (
            <label key={m.id}>
              <input
                type="checkbox"
                checked={mailboxIds.includes(m.id)}
                onChange={() => setMailboxIds((ids) => toggle(ids, m.id))}
              />
              {m.email}
            </label>
          ))}
        </div>
      </div>

      <div className="card">
        <h2>Sequence</h2>
        <p className="hint" style={{ marginTop: -6 }}>
          Variables: {"{{firstName}}"}, {"{{lastName}}"}, {"{{company}}"}, any CSV column. Add a fallback with {"{{firstName|there}}"}. Spintax: {"{Hi|Hello|Hey}"}. Leave a follow-up subject empty to reply in the same thread.
        </p>
        {steps.map((s, i) => (
          <div className="step" key={i}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <b>Step {i + 1}</b>
              {i > 0 && (
                <button type="button" className="danger sm" onClick={() => setSteps((x) => x.filter((_, k) => k !== i))}>
                  Remove
                </button>
              )}
            </div>
            {i > 0 && (
              <div className="row" style={{ maxWidth: 240 }}>
                <div>
                  <label>Wait (days after previous step)</label>
                  <input type="number" min={1} max={60} value={s.delayDays} onChange={(e) => updateStep(i, { delayDays: Number(e.target.value) })} />
                </div>
              </div>
            )}
            <div className="row">
              <div>
                <label>Subject</label>
                <input
                  value={s.subject}
                  onChange={(e) => updateStep(i, { subject: e.target.value })}
                  placeholder={i > 0 ? "(empty = reply in same thread)" : ""}
                  required={i === 0}
                />
              </div>
              <div>
                <label>Body</label>
                <textarea value={s.body} onChange={(e) => updateStep(i, { body: e.target.value })} required />
              </div>
            </div>
          </div>
        ))}
        <button
          type="button"
          className="ghost"
          onClick={() => setSteps((x) => [...x, { delayDays: 3, subject: "", body: "Hi {{firstName|there}},\n\nJust following up on my last note.\n\nBest,\nYour name" }])}
        >
          + Add follow-up
        </button>
      </div>

      <div className="card">
        <h2>Schedule</h2>
        <div className="row c3">
          <div>
            <label>Time zone</label>
            <input value={timezone} onChange={(e) => setTimezone(e.target.value)} />
          </div>
          <div>
            <label>Send from (hour)</label>
            <input type="number" min={0} max={23} value={start} onChange={(e) => setStart(Number(e.target.value))} />
          </div>
          <div>
            <label>Send until (hour)</label>
            <input type="number" min={1} max={24} value={end} onChange={(e) => setEnd(Number(e.target.value))} />
          </div>
        </div>
        <label>Days</label>
        <div className="checks" style={{ marginBottom: 12 }}>
          {DAYS.map((d) => (
            <label key={d.n}>
              <input type="checkbox" checked={days.includes(d.n)} onChange={() => setDays((x) => toggle(x, d.n))} />
              {d.l}
            </label>
          ))}
        </div>
        <label style={{ display: "flex", gap: 8, alignItems: "center", fontWeight: 400 }}>
          <input type="checkbox" style={{ width: "auto" }} checked={trackOpens} onChange={(e) => setTrackOpens(e.target.checked)} />
          Track opens
        </label>
      </div>

      {error && <div className="err">{error}</div>}
      <button disabled={busy}>{busy ? "Saving…" : "Save as draft"}</button>
      <span className="hint" style={{ marginLeft: 10 }}>You can launch it from the Campaigns page.</span>
    </form>
  );
}
