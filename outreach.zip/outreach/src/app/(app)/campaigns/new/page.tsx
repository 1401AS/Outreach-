import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import CampaignBuilder from "./CampaignBuilder";

export default async function NewCampaignPage() {
  const user = await getUser();
  if (!user) redirect("/login");

  const [lists, mailboxes] = await Promise.all([
    prisma.leadList.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      select: { id: true, name: true, _count: { select: { leads: true } } },
    }),
    prisma.mailbox.findMany({
      where: { userId: user.id, status: "OK" },
      select: { id: true, email: true },
    }),
  ]);

  if (lists.length === 0 || mailboxes.length === 0) {
    return (
      <>
        <h1>New campaign</h1>
        <div className="card">
          <p style={{ marginTop: 0 }}>Before creating a campaign you need:</p>
          <ul>
            <li>{mailboxes.length > 0 ? "✓" : "✗"} at least one working <Link href="/mailboxes">email account</Link></li>
            <li>{lists.length > 0 ? "✓" : "✗"} at least one <Link href="/leads">lead list</Link></li>
          </ul>
        </div>
      </>
    );
  }

  return (
    <>
      <h1>New campaign</h1>
      <p className="sub">Build your sequence, pick who sends it and when.</p>
      <CampaignBuilder
        lists={lists.map((l) => ({ id: l.id, name: `${l.name} (${l._count.leads})` }))}
        mailboxes={mailboxes}
      />
    </>
  );
}
