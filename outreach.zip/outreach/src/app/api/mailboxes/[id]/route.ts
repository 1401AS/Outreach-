import { prisma } from "@/lib/db";
import { withUser } from "@/lib/api";

export const DELETE = withUser(async (_req, { params }, user) => {
  await prisma.mailbox.deleteMany({ where: { id: params.id, userId: user.id } });
  return { ok: true };
});
