import { z } from "zod";
import { prisma } from "@/lib/db";
import { withUser, HttpError } from "@/lib/api";
import { encrypt } from "@/lib/crypto";
import { verifyConnection } from "@/lib/mail";

const schema = z.object({
  email: z.string().email().transform((s) => s.toLowerCase()),
  fromName: z.string().min(1),
  smtpHost: z.string().min(1),
  smtpPort: z.coerce.number().int().min(1).max(65535),
  imapHost: z.string().min(1),
  imapPort: z.coerce.number().int().min(1).max(65535),
  username: z.string().min(1),
  password: z.string().min(1),
  dailyLimit: z.coerce.number().int().min(1).max(500).default(30),
});

export const GET = withUser(async (_req, _ctx, user) => {
  const mailboxes = await prisma.mailbox.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      email: true,
      fromName: true,
      dailyLimit: true,
      sentToday: true,
      status: true,
      lastError: true,
    },
  });
  return { mailboxes };
});

export const POST = withUser(async (req, _ctx, user) => {
  const data = schema.parse(await req.json());
  try {
    await verifyConnection(data);
  } catch (e) {
    throw new HttpError(400, (e as Error).message);
  }
  const { password, ...rest } = data;
  const existing = await prisma.mailbox.findUnique({
    where: { userId_email: { userId: user.id, email: data.email } },
  });
  if (existing) throw new HttpError(409, "This mailbox is already connected");
  const mailbox = await prisma.mailbox.create({
    data: { ...rest, userId: user.id, passwordEnc: encrypt(password) },
  });
  return { id: mailbox.id };
});
