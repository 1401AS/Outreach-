import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

const page = (msg: string) =>
  new Response(
    `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unsubscribe</title></head>` +
      `<body style="font-family:system-ui,sans-serif;max-width:480px;margin:15vh auto;padding:0 20px;text-align:center"><h2>${msg}</h2></body></html>`,
    { headers: { "Content-Type": "text/html; charset=utf-8" } }
  );

async function unsubscribe(id: string) {
  const cl = await prisma.campaignLead.findUnique({ where: { id }, select: { id: true, leadId: true } });
  if (!cl) return false;
  await prisma.$transaction([
    prisma.lead.update({ where: { id: cl.leadId }, data: { unsubscribed: true } }),
    // stop this lead everywhere they are still active
    prisma.campaignLead.updateMany({
      where: { leadId: cl.leadId, status: "ACTIVE" },
      data: { status: "UNSUBSCRIBED", nextSendAt: null },
    }),
  ]);
  return true;
}

// GET supports link clicks; POST supports RFC 8058 one-click (List-Unsubscribe-Post)
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const ok = await unsubscribe(params.id);
  return ok ? page("You have been unsubscribed.") : page("This link is no longer valid.");
}

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  const ok = await unsubscribe(params.id);
  return new Response(ok ? "ok" : "not found", { status: ok ? 200 : 404 });
}
