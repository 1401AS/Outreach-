import Papa from "papaparse";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { withUser, HttpError } from "@/lib/api";

const schema = z.object({
  listName: z.string().min(1).max(100),
  csv: z.string().min(1),
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const KNOWN = ["email", "firstname", "lastname", "company"];

const norm = (h: string) => h.trim().toLowerCase().replace(/[\s_-]+/g, "");

export const POST = withUser(async (req, _ctx, user) => {
  const { listName, csv } = schema.parse(await req.json());

  const parsed = Papa.parse<Record<string, string>>(csv, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  });
  if (!parsed.meta.fields?.some((f) => norm(f) === "email")) {
    throw new HttpError(400, 'CSV needs an "email" column');
  }

  const seen = new Set<string>();
  let invalid = 0;
  let duplicates = 0;
  const rows: {
    email: string;
    firstName: string | null;
    lastName: string | null;
    company: string | null;
    vars: Record<string, string>;
  }[] = [];

  for (const raw of parsed.data) {
    const byNorm: Record<string, string> = {};
    const extra: Record<string, string> = {};
    for (const [k, v] of Object.entries(raw)) {
      const n = norm(k);
      byNorm[n] = (v ?? "").trim();
      if (!KNOWN.includes(n) && v?.trim()) {
        // keep custom columns, camelCased so {{customVar}} works
        const key = k.trim().replace(/[^a-zA-Z0-9]+(.)?/g, (_m, c: string) => (c ? c.toUpperCase() : ""));
        extra[key.charAt(0).toLowerCase() + key.slice(1)] = v.trim();
      }
    }
    const email = (byNorm["email"] ?? "").toLowerCase();
    if (!EMAIL_RE.test(email)) {
      invalid++;
      continue;
    }
    if (seen.has(email)) {
      duplicates++;
      continue;
    }
    seen.add(email);
    rows.push({
      email,
      firstName: byNorm["firstname"] || null,
      lastName: byNorm["lastname"] || null,
      company: byNorm["company"] || null,
      vars: extra,
    });
  }

  if (rows.length === 0) throw new HttpError(400, "No valid rows found in CSV");

  const list = await prisma.leadList.create({ data: { userId: user.id, name: listName } });
  await prisma.lead.createMany({
    data: rows.map((r) => ({ ...r, listId: list.id })),
    skipDuplicates: true,
  });

  return { listId: list.id, imported: rows.length, invalid, duplicates };
});
