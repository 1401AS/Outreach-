import { z } from "zod";
import { prisma } from "@/lib/db";
import { withUser, HttpError } from "@/lib/api";

const schema = z.object({ label: z.string().max(40).nullable() });

export const PATCH = withUser(async (req, { params }, user) => {
  const { label } = schema.parse(await req.json());
  const cl = await prisma.campaignLead.findFirst({
    where: { id: params.id, campaign: { userId: user.id } },
  });
  if (!cl) throw new HttpError(404, "Not found");
  await prisma.campaignLead.update({ where: { id: cl.id }, data: { label } });
  return { ok: true };
});
