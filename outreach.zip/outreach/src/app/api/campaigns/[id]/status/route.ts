import { z } from "zod";
import { prisma } from "@/lib/db";
import { withUser, HttpError } from "@/lib/api";

const schema = z.object({ action: z.enum(["launch", "pause", "resume"]) });

export const POST = withUser(async (req, { params }, user) => {
  const { action } = schema.parse(await req.json());
  const campaign = await prisma.campaign.findFirst({
    where: { id: params.id, userId: user.id },
  });
  if (!campaign) throw new HttpError(404, "Campaign not found");

  if (action === "pause") {
    await prisma.campaign.update({ where: { id: campaign.id }, data: { status: "PAUSED" } });
    return { status: "PAUSED" };
  }

  if (action === "launch") {
    if (campaign.status !== "DRAFT") throw new HttpError(400, "Campaign was already launched");
    const leads = await prisma.lead.findMany({
      where: { listId: campaign.listId, unsubscribed: false },
      select: { id: true },
    });
    if (leads.length === 0) throw new HttpError(400, "The lead list has no sendable leads");
    const now = new Date();
    await prisma.campaignLead.createMany({
      data: leads.map((l) => ({
        campaignId: campaign.id,
        leadId: l.id,
        status: "ACTIVE" as const,
        nextSendAt: now,
      })),
      skipDuplicates: true,
    });
  }

  // launch or resume
  if (action === "resume" && campaign.status !== "PAUSED") {
    throw new HttpError(400, "Campaign is not paused");
  }
  await prisma.campaign.update({ where: { id: campaign.id }, data: { status: "ACTIVE" } });
  return { status: "ACTIVE" };
});
