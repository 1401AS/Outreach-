import { z } from "zod";
import { prisma } from "@/lib/db";
import { withUser, HttpError } from "@/lib/api";

const schema = z.object({
  name: z.string().min(1).max(120),
  listId: z.string().min(1),
  mailboxIds: z.array(z.string()).min(1, "Select at least one mailbox"),
  timezone: z.string().default("UTC"),
  sendStartHour: z.number().int().min(0).max(23).default(9),
  sendEndHour: z.number().int().min(1).max(24).default(17),
  sendDays: z.array(z.number().int().min(1).max(7)).min(1).default([1, 2, 3, 4, 5]),
  trackOpens: z.boolean().default(true),
  steps: z
    .array(
      z.object({
        delayDays: z.number().int().min(0).max(60),
        subject: z.string().default(""),
        body: z.string().min(1, "Every step needs a body"),
      })
    )
    .min(1, "Add at least one step"),
});

export const POST = withUser(async (req, _ctx, user) => {
  const d = schema.parse(await req.json());
  if (d.sendEndHour <= d.sendStartHour) throw new HttpError(400, "Send window end must be after start");
  if (!d.steps[0].subject.trim()) throw new HttpError(400, "The first step needs a subject");

  const list = await prisma.leadList.findFirst({ where: { id: d.listId, userId: user.id } });
  if (!list) throw new HttpError(400, "Lead list not found");
  const mailboxes = await prisma.mailbox.findMany({
    where: { id: { in: d.mailboxIds }, userId: user.id },
    select: { id: true },
  });
  if (mailboxes.length !== d.mailboxIds.length) throw new HttpError(400, "Mailbox not found");

  const campaign = await prisma.campaign.create({
    data: {
      userId: user.id,
      name: d.name,
      listId: d.listId,
      timezone: d.timezone,
      sendStartHour: d.sendStartHour,
      sendEndHour: d.sendEndHour,
      sendDays: d.sendDays.join(","),
      trackOpens: d.trackOpens,
      mailboxes: { create: mailboxes.map((m) => ({ mailboxId: m.id })) },
      steps: {
        create: d.steps.map((s, i) => ({
          position: i,
          delayDays: i === 0 ? 0 : s.delayDays,
          subject: s.subject,
          body: s.body,
        })),
      },
    },
  });
  return { id: campaign.id };
});
