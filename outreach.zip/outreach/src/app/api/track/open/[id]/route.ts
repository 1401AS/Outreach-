import { prisma } from "@/lib/db";

// 1x1 transparent GIF
const PIXEL = Buffer.from("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", "base64");

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const msg = await prisma.message.findUnique({
      where: { id: params.id },
      select: { id: true, openedAt: true, direction: true },
    });
    if (msg && msg.direction === "OUT") {
      await prisma.message.update({
        where: { id: msg.id },
        data: { openCount: { increment: 1 }, openedAt: msg.openedAt ?? new Date() },
      });
    }
  } catch {
    // never fail the pixel
  }
  return new Response(PIXEL, {
    headers: {
      "Content-Type": "image/gif",
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}
