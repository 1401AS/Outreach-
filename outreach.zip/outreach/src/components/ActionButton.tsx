"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  url: string;
  method?: "POST" | "DELETE" | "PATCH";
  body?: unknown;
  label: string;
  className?: string;
  confirm?: string;
  redirectTo?: string;
};

/** Small button that calls an API route, then refreshes the current page. */
export default function ActionButton({ url, method = "POST", body, label, className, confirm: ask, redirectTo }: Props) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function run() {
    if (ask && !window.confirm(ask)) return;
    setBusy(true);
    setError("");
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    setBusy(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Failed");
      return;
    }
    if (redirectTo) router.push(redirectTo);
    router.refresh();
  }

  return (
    <>
      <button className={className} disabled={busy} onClick={run}>
        {busy ? "…" : label}
      </button>
      {error && <span className="err" style={{ marginLeft: 8 }}>{error}</span>}
    </>
  );
}
