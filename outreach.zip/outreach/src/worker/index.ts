import { Worker } from "bullmq";
import { redis, sendQueue, SEND_QUEUE } from "../lib/queue";
import { sendStep } from "./send";
import { scheduleDue } from "./scheduler";
import { syncAllMailboxes } from "./imap";

const worker = new Worker(
  SEND_QUEUE,
  async (job) => {
    await sendStep(job.data.campaignLeadId as string);
  },
  { connection: redis(), concurrency: 3 }
);
worker.on("failed", (job, err) => console.error(`[worker] job ${job?.id} failed:`, err.message));

function loop(name: string, everyMs: number, fn: () => Promise<void>) {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await fn();
    } catch (e) {
      console.error(`[${name}]`, (e as Error).message);
    } finally {
      running = false;
    }
  };
  void tick();
  return setInterval(tick, everyMs);
}

const timers = [
  loop("scheduler", 30_000, () => scheduleDue(sendQueue())),
  loop("imap", 60_000, syncAllMailboxes),
];

console.log("[worker] started: scheduler every 30s, IMAP sync every 60s");

async function shutdown() {
  timers.forEach(clearInterval);
  await worker.close();
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
