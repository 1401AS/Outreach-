import { randomUUID } from "node:crypto";
import { simpleParser, type ParsedMail } from "mailparser";
import type { Mailbox } from "@prisma/client";
import { prisma } from "../lib/db";
import { imapClient, settingsFromMailbox } from "../lib/mail";

function referencedIds(mail: ParsedMail): string[] {
  const ids = new Set<string>();
  if (mail.inReplyTo) ids.add(mail.inReplyTo);
  const r = mail.references;
  if (Array.isArray(r)) r.forEach((x) => ids.add(x));
  else if (typeof r === "string") r.split(/\s+/).filter(Boolean).forEach((x) => ids.add(x));
  return [...ids];
}

async function handleIncoming(mb: Mailbox, mail: ParsedMail) {
  const from = mail.from?.value?.[0]?.address?.toLowerCase() ?? "";
  const refs = referencedIds(mail);

  const out = refs.length
    ? await prisma.message.findFirst({
        where: {
          direction: "OUT",
          mailboxId: mb.id,
          messageId: { in: refs },
          campaignLeadId: { not: null },
        },
        include: { campaignLead: true },
      })
    : null;

  const isBounce =
    /mailer-daemon|postmaster/.test(from) ||
    /undeliver|delivery status notification|delivery failure|returned mail/i.test(mail.subject ?? "");

  if (isBounce) {
    let cl = out?.campaignLead ?? null;
    if (!cl) {
      // Fall back to finding which of this mailbox's active leads is named in the bounce text.
      const text = (mail.text ?? "").toLowerCase();
      const candidates = await prisma.campaignLead.findMany({
        where: { mailboxId: mb.id, status: "ACTIVE" },
        include: { lead: true },
      });
      cl = candidates.find((c) => text.includes(c.lead.email.toLowerCase())) ?? null;
    }
    if (cl && cl.status !== "BOUNCED") {
      await prisma.campaignLead.update({
        where: { id: cl.id },
        data: { status: "BOUNCED", nextSendAt: null },
      });
      console.log(`[imap] bounce for campaignLead ${cl.id}`);
    }
    return;
  }

  const cl = out?.campaignLead;
  if (!cl) return; // not a reply to one of our campaign emails

  // Ignore out-of-office and other automatic replies so they don't stop the sequence.
  const auto = String(mail.headers.get("auto-submitted") ?? "").toLowerCase();
  if (auto && auto !== "no") return;

  const messageId = mail.messageId ?? `<${randomUUID()}@local>`;
  const dup = await prisma.message.findFirst({ where: { messageId, direction: "IN" } });
  if (dup) return;

  await prisma.message.create({
    data: {
      userId: mb.userId,
      mailboxId: mb.id,
      campaignLeadId: cl.id,
      direction: "IN",
      messageId,
      subject: mail.subject ?? "",
      body: (mail.text ?? "").slice(0, 20_000),
      fromEmail: from,
      toEmail: mb.email,
    },
  });
  if (cl.status === "ACTIVE" || cl.status === "COMPLETED") {
    await prisma.campaignLead.update({
      where: { id: cl.id },
      data: { status: "REPLIED", nextSendAt: null },
    });
  }
  console.log(`[imap] reply from ${from} on ${mb.email}`);
}

export async function syncMailbox(mb: Mailbox) {
  const client = imapClient(settingsFromMailbox(mb));
  try {
    await client.connect();
    const lock = await client.getMailboxLock("INBOX");
    try {
      const uidNext = (client.mailbox as { uidNext?: number } | false)
        ? ((client.mailbox as { uidNext?: number }).uidNext ?? 1)
        : 1;

      // First sync: start from "now" so we don't ingest the whole historical inbox.
      if (mb.lastImapUid === 0) {
        await prisma.mailbox.update({
          where: { id: mb.id },
          data: { lastImapUid: Math.max(uidNext - 1, 1), lastError: null },
        });
        return;
      }

      let maxUid = mb.lastImapUid;
      for await (const msg of client.fetch(`${mb.lastImapUid + 1}:*`, { uid: true, source: true }, { uid: true })) {
        if (msg.uid <= mb.lastImapUid) continue; // "n:*" always returns the last message
        maxUid = Math.max(maxUid, msg.uid);
        if (!msg.source) continue;
        try {
          await handleIncoming(mb, await simpleParser(msg.source));
        } catch (e) {
          console.error("[imap] failed to process message", (e as Error).message);
        }
      }
      await prisma.mailbox.update({
        where: { id: mb.id },
        data: { lastImapUid: maxUid, lastError: null },
      });
    } finally {
      lock.release();
    }
  } catch (e) {
    const err = e as Error & { authenticationFailed?: boolean };
    console.error(`[imap] ${mb.email}:`, err.message);
    await prisma.mailbox.update({
      where: { id: mb.id },
      data: {
        lastError: `IMAP: ${err.message}`.slice(0, 300),
        ...(err.authenticationFailed ? { status: "ERROR" } : {}),
      },
    });
  } finally {
    try {
      await client.logout();
    } catch {
      // connection may already be closed
    }
  }
}

export async function syncAllMailboxes() {
  const mailboxes = await prisma.mailbox.findMany({ where: { status: "OK" } });
  for (const mb of mailboxes) await syncMailbox(mb);
}
