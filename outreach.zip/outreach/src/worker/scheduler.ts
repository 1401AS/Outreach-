import type { Queue } from "bullmq";
import { prisma } from "../lib/db";

/** Finds leads that are due, claims them, and queues one send job per lead. */
export async function scheduleDue(queue: Queue) {
  const now = new Date();
  const due = await prisma.campaignLead.findMany({
    where: { status: "ACTIVE", nextSendAt: { lte: now }, campaign: { status: "ACTIVE" } },
    select: { id: true },
    take: 200,
  });

  for (const { id } of due) {
    // Claim: push nextSendAt forward so overlapping ticks never double-queue the same lead.
    // sendStep() sets the real next time (or releases the lead) when it finishes.
    const claimed = await prisma.campaignLead.updateMany({
      where: { id, nextSendAt: { lte: now } },
      data: { nextSendAt: new Date(now.getTime() + 10 * 60_000) },
    });
    if (claimed.count === 1) {
      await queue.add("send", { campaignLeadId: id }, { delay: Math.floor(Math.random() * 25_000) });
    }
  }

  // Mark campaigns finished once nobody is left to email.
  const active = await prisma.campaign.findMany({ where: { status: "ACTIVE" }, select: { id: true } });
  for (const c of active) {
    const remaining = await prisma.campaignLead.count({
      where: { campaignId: c.id, status: "ACTIVE" },
    });
    if (remaining === 0) {
      await prisma.campaign.update({ where: { id: c.id }, data: { status: "COMPLETED" } });
    }
  }
}
