import { randomUUID } from "node:crypto";
import type { Mailbox } from "@prisma/client";
import { prisma } from "../lib/db";
import { settingsFromMailbox, smtpTransport } from "../lib/mail";
import { escapeHtml, leadVars, render, textToHtml } from "../lib/template";
import { isWithinSendWindow, todayKey } from "../lib/schedule";

const MIN = 60_000;
const DAY = 24 * 60 * MIN;

async function defer(campaignLeadId: string, ms: number) {
  await prisma.campaignLead.update({
    where: { id: campaignLeadId },
    data: { nextSendAt: new Date(Date.now() + ms) },
  });
}

/**
 * Picks a mailbox that still has capacity today and reserves one send on it.
 * Follow-ups stick to the mailbox that sent the first email so the thread stays intact.
 */
async function reserveMailbox(ids: string[], preferred: string | null): Promise<Mailbox | null> {
  const today = todayKey();
  await prisma.mailbox.updateMany({
    where: { id: { in: ids }, sentTodayDate: { not: today } },
    data: { sentToday: 0, sentTodayDate: today },
  });
  const available = await prisma.mailbox.findMany({
    where: { id: { in: ids }, status: "OK" },
    orderBy: { sentToday: "asc" },
  });
  const pinned = preferred && ids.includes(preferred) ? preferred : null;
  const candidates = pinned ? available.filter((m) => m.id === pinned) : available;

  for (const mb of candidates) {
    const res = await prisma.mailbox.updateMany({
      where: { id: mb.id, sentToday: { lt: mb.dailyLimit } },
      data: { sentToday: { increment: 1 } },
    });
    if (res.count === 1) return mb;
  }
  return null;
}

export async function sendStep(campaignLeadId: string) {
  const cl = await prisma.campaignLead.findUnique({
    where: { id: campaignLeadId },
    include: {
      lead: true,
      campaign: {
        include: { steps: { orderBy: { position: "asc" } }, mailboxes: true },
      },
    },
  });
  if (!cl || cl.status !== "ACTIVE" || cl.campaign.status !== "ACTIVE") return;
  const { campaign, lead } = cl;

  if (lead.unsubscribed) {
    await prisma.campaignLead.update({
      where: { id: cl.id },
      data: { status: "UNSUBSCRIBED", nextSendAt: null },
    });
    return;
  }

  if (!isWithinSendWindow(campaign)) return defer(cl.id, 15 * MIN);

  const step = campaign.steps[cl.currentStep];
  if (!step) {
    await prisma.campaignLead.update({
      where: { id: cl.id },
      data: { status: "COMPLETED", nextSendAt: null },
    });
    return;
  }

  const mb = await reserveMailbox(
    campaign.mailboxes.map((m) => m.mailboxId),
    cl.mailboxId
  );
  if (!mb) return defer(cl.id, 60 * MIN); // all mailboxes at daily limit (or errored)

  const vars = leadVars(lead);
  const isFollowUp = cl.currentStep > 0 && !!cl.threadMessageId;
  const ownSubject = step.subject.trim();
  let subject = ownSubject ? render(ownSubject, vars) : cl.firstSubject ?? "";
  if (isFollowUp && !ownSubject && !/^re:/i.test(subject)) subject = `Re: ${subject}`;

  const appUrl = (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");
  const address = process.env.COMPANY_ADDRESS ?? "";
  const unsubUrl = `${appUrl}/api/unsubscribe/${cl.id}`;

  const bodyText = render(step.body, vars);
  const text = `${bodyText}\n\n--\n${address}\nUnsubscribe: ${unsubUrl}`;

  const domain = mb.email.split("@")[1] ?? "localhost";
  const messageId = `<${randomUUID()}@${domain}>`;

  const msg = await prisma.message.create({
    data: {
      userId: mb.userId,
      mailboxId: mb.id,
      campaignLeadId: cl.id,
      direction: "OUT",
      messageId,
      subject,
      body: bodyText,
      fromEmail: mb.email,
      toEmail: lead.email,
    },
  });

  const pixel = campaign.trackOpens
    ? `<img src="${appUrl}/api/track/open/${msg.id}" width="1" height="1" alt="" style="display:none">`
    : "";
  const html =
    `<div>${textToHtml(bodyText)}</div>` +
    `<p style="color:#888;font-size:12px;margin-top:24px">${escapeHtml(address)}<br>` +
    `<a href="${unsubUrl}" style="color:#888">Unsubscribe</a></p>${pixel}`;

  try {
    await smtpTransport(settingsFromMailbox(mb)).sendMail({
      from: { name: mb.fromName, address: mb.email },
      to: lead.email,
      subject,
      text,
      html,
      messageId,
      inReplyTo: isFollowUp ? cl.threadMessageId! : undefined,
      references: isFollowUp ? cl.threadMessageId! : undefined,
      headers: {
        "List-Unsubscribe": `<${unsubUrl}>`,
        "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
      },
    });
  } catch (e) {
    const err = e as Error & { code?: string; rejected?: string[] };
    console.error(`[send] ${mb.email} -> ${lead.email} failed:`, err.message);
    await prisma.message.delete({ where: { id: msg.id } });
    await prisma.mailbox.update({
      where: { id: mb.id },
      data: {
        sentToday: { decrement: 1 },
        lastError: err.message.slice(0, 300),
        ...(err.code === "EAUTH" ? { status: "ERROR" } : {}),
      },
    });
    if (Array.isArray(err.rejected) && err.rejected.length > 0) {
      // recipient refused by the server: treat as a hard bounce
      await prisma.campaignLead.update({
        where: { id: cl.id },
        data: { status: "BOUNCED", nextSendAt: null },
      });
    } else {
      await defer(cl.id, 30 * MIN);
    }
    return;
  }

  const next = campaign.steps[cl.currentStep + 1];
  const jitter = Math.floor(Math.random() * 20 * MIN);
  await prisma.campaignLead.update({
    where: { id: cl.id },
    data: {
      currentStep: cl.currentStep + 1,
      mailboxId: mb.id,
      threadMessageId: cl.threadMessageId ?? messageId,
      firstSubject: cl.firstSubject ?? subject,
      status: next ? "ACTIVE" : "COMPLETED",
      nextSendAt: next ? new Date(Date.now() + next.delayDays * DAY + jitter) : null,
    },
  });
  console.log(`[send] ${mb.email} -> ${lead.email} (step ${cl.currentStep + 1}/${campaign.steps.length})`);
}
